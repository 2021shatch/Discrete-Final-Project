#to run either method, simply copy and paste into main and run 
  
  
  